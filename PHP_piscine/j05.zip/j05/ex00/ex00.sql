CREATE DATABASE db_eterman;
