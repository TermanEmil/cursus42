INSERT INTO ft_table
	(login, groupe, creation_date)
VALUES
	('loki', 'staff', '2013-05-01'),
	('scadoux', 'student', '2014-01-01'),
	('chap', 'staff', '2011-04-27'),
	('bambou', 'staff', '2014-03-01'),
	('fantomet', 'staff', '2010-04-03');